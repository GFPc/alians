import base64
import hashlib
import os
import random

import pymysql
import sys

config = {
  "database": {
    "type": "mysql",
    "host": "localhost",
    "port": "3306",
    "user": "root",
    "password": "93029302",
    "database": "AliansDB"
  }
}
def db_connect():
    conn = pymysql.connect(
        host=config["database"]["host"],
        port=int(config["database"]["port"]),
        user=config["database"]["user"],
        password=config["database"]["password"],
        db=config["database"]["database"],
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )
    return conn
def db_select(sql):
    conn = db_connect()
    cursor = conn.cursor()
    cursor.execute(sql)
    result = cursor.fetchall()
    cursor.close()
    conn.close()
    return result
def db_insert(sql):
    conn = db_connect()
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()
    cursor.close()
    conn.close()
def db_update(sql):
    conn = db_connect()
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()
    cursor.close()
    conn.close()
def db_delete(sql):
    conn = db_connect()
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()
    cursor.close()
    conn.close()