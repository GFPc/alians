import base64
import hashlib
import json
from io import BytesIO

import requests
from PIL import Image
from flask import *
from flask_cors import CORS, cross_origin

from db import db_select, db_insert, db_delete
from utils.isJson import isJson


def build_response(data,headers={},status=200):
    res = make_response(json.dumps(data))
    res.headers['Content-Type'] = 'text/plain'
    res.headers['Server'] = 'Foobar'
    res.headers["Allow-Origin"] = "*"
    res.headers["Access-Control-Allow-Origin"] = "*"
    for i in headers:
        res.headers[i] = headers[i]
    res.status_code = status
    return res

app = Flask(__name__)
cors = CORS(app)

@app.route('/')
def hello_world():
    return 'Hello, World!'

@app.route("/objects")
def objects():
    objects = db_select("SELECT * FROM buildings")
    for i in objects:
        default_data = {
            "name": "",
            "address": "",
            "features": [],
            "specifications": [],
            "contacts": [],
            "desctiption": "",
            "low_price": 0,
            "high_price": 0
        }
        for j in default_data:
            if j not in i:
                i[j] = default_data[j]
        try:
            i["images"] = json.loads(i["images"])
        except:pass
        try:
            i["features"] = json.loads(i["features"])
        except:pass
        try:
            i["contacts"] = json.loads(i["contacts"])
        except:pass
        try:
            i["specifications"] = json.loads(i["specifications"])
        except:pass
    return build_response(objects, {"Content-Type": "application/json"})
@app.route("/object", methods=["POST"])
def object():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        objects = db_select("SELECT * FROM buildings WHERE id = '" + data["object_id"] + "'")
        for i in objects:
            default_data = {
                "name": "",
                "address": "",
                "features": [],
                "specifications": [],
                "contacts": [],
                "description": "",
                "low_price": 0,
                "high_price": 0
            }
            for j in default_data:
                if j not in i:
                    i[j] = default_data[j]
            try:
                i["images"] = json.loads(i["images"])
            except:
                pass
            try:
                i["features"] = json.loads(i["features"])
            except:
                pass
            try:
                i["contacts"] = json.loads(i["contacts"])
            except:
                pass
            try:
                i["specifications"] = json.loads(i["specifications"])
            except:
                pass
        return build_response(objects[0], {"Content-Type": "application/json"})
@app.route("/src/img", methods=["POST"])
def src_img():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        print(data)
        db_res = db_select("SELECT id,data FROM images WHERE id IN ('" + "\',\'".join(data["id_list"]) + "')")
        for i in db_res:
            i["data"] = "data:image/png;base64," + i["data"]
        return build_response(db_res, )
    elif request.method == "GET":
        img = db_select(f"SELECT data FROM images WHERE id = '{request.args.get('id')}'")
        if len(img) == 0:
            return build_response({"data": ""}, )
        else:
            return build_response({"data": "data:image/png;base64," + img[0]["data"]},)
@app.route("/admin/object/create", methods=["POST"])
def admin_object_create():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        print(data)
        default_data = {
            "name": "",
            "address": "",
            "features": [],
            "specifications": [],
            "contacts": [],
            "desctiption": "",
            "low_price": 0,
            "high_price": 0
        }
        for i in data:
            if data[i] != default_data[i]:
                default_data[i] = data[i]


        db_insert(f"INSERT INTO buildings(name,address,features,specifications,contacts,description,low_price,high_price) VALUES ('{default_data['name']}','{default_data['address']}','{json.dumps(default_data['features'])}','{json.dumps(default_data['specifications'])}','{json.dumps(default_data['contacts'])}','{default_data['desctiption']}','{default_data['low_price']}','{default_data['high_price']}')")
        id = db_select("SELECT MAX(id) as `max` FROM buildings")[0]["max"]
        return build_response({"object_id":id},{},200)

def resizeImage(image: bytes, width, height):
    image = Image.open(BytesIO(image))
    image = image.resize((width, height))
    new_image = BytesIO()
    image.save(new_image, format="PNG")
    new_image = new_image.getvalue()
    return new_image
@app.route("/admin/img/create", methods=["POST"])
def admin_img_create():
    PHOTO_SIZE_HEIGHT = 400
    PHOTO_SIZE_WIDTH = 600
    PHOTO_MOBILE_SIZE_HEIGHT = 200
    PHOTO_MOBILE_SIZE_WIDTH = 300


    if request.method == "POST":
        data = request.data.decode("utf-8")
        object_id = json.loads(request.form.get("data"))["object_id"]
        print("DATA",data,json.loads(request.form.get("data"))["object_id"])
        print("FILES COUNT",len(request.files))
        object_img_hashs = []
        #print(request.files["files_upload"].stream.read())
        for i in request.files:
            print("SERVING FILE: " + request.files[i].filename)
            print(request.files[i].filename)
            file = request.files[i].stream.read()
            data = [
                base64.b64encode(
                    resizeImage(file, PHOTO_SIZE_WIDTH, PHOTO_SIZE_HEIGHT)).decode('utf-8'),
                base64.b64encode(
                    resizeImage(file, PHOTO_MOBILE_SIZE_WIDTH, PHOTO_MOBILE_SIZE_HEIGHT)).decode('utf-8')
            ]
            check_exists = db_select(f"SELECT * FROM images WHERE data IN ('{data[0]}','{data[1]}')")
            if len(check_exists) == 0:
                pc_img_id = hashlib.sha256(data[0].encode('utf-8')).hexdigest()
                object_img_hashs.append(pc_img_id)
                mobile_img_id = "mobile_" + pc_img_id
                db_insert(f"INSERT INTO images(id,data) VALUES ('{pc_img_id}','{data[0]}'),('{mobile_img_id}','{data[1]}')")
            else:
                print("img exists")
                object_img_hashs.append(check_exists[0]["id"])
        object_img_hashs = {
            "id_list": object_img_hashs
        }
        db_insert(f"UPDATE buildings SET images = '{json.dumps(object_img_hashs)}' WHERE id = '{object_id}'")
        return build_response({},{},200)
@app.route("/admin/object/delete", methods=["POST"])
def admin_object_delete():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        db_delete(f"DELETE FROM buildings WHERE id = '{data['object_id']}'")
        return build_response({},{},200)
@app.route("/admin/object/edit", methods=["POST"])
def admin_object_edit():
    if request.method == "POST":
        data = request.data.decode("utf-8")
        data = json.loads(data)
        print(data)
        old_object_data = db_select(f"SELECT * FROM buildings WHERE id = '{data['id']}'")[0]
        old_object_data["images"] = json.loads(old_object_data["images"])
        print(old_object_data)
        default_data = {
            "name": "",
            "address": "",
            "features": [],
            "specifications": [],
            "contacts": [],
            "description": "",
            "low_price": "",
            "high_price": "",
            "images": []
        }



        for i in default_data:
            if i not in old_object_data:
                old_object_data[i] = default_data[i]

        for i in data:
            if data[i] != old_object_data[i]:
                old_object_data[i] = data[i]
            else:
                del old_object_data[i]

        total_data = old_object_data
        update_script = "UPDATE buildings SET "
        del total_data["id"]
        type_list = {
            "id": "int",
            "name": "str",
            "address": "str",
            "features": "json",
            "specifications": "json",
            "contacts": "json",
            "description": "str",
            "low_price": "str",
            "high_price": "str",
            "images": "json"
        }
        for i in total_data:
            if type_list[i] == "int":
                update_script += i + " = " + str(total_data[i]) + ","
            if type_list[i] == "str":
                update_script += i + " = '" + total_data[i].replace("'","\\'").replace('"','\\"') + "',"
            if type_list[i] == "json":
                update_script += f"{i} = '{json.dumps(total_data[i],ensure_ascii=False)}',"
        update_script = update_script[:-1]
        update_script += f" WHERE id = '{data['id']}'"
        print(update_script)

        db_insert(update_script)
        return build_response({},{},200)
@app.route("/admin/img/edit", methods=["POST"])
def admin_img_edit():
    """{
        "object_id": 0,
        "old_img": [],
    }"""
    if request.method == "POST":
        object_id = request.form.get("object_id")
        img = json.loads(request.form.get("img"))
        print("//admin/img/edit",object_id,img,len(request.files))


        total_images_set = []
        total_images_set += img

        object_img_hashs = []
        # print(request.files["files_upload"].stream.read())
        for i in request.files:
            data = base64.b64encode(request.files[i].stream.read()).decode('utf-8')
            check_exists = db_select(f"SELECT * FROM images WHERE data = '{data}'")
            if len(check_exists) == 0:
                img_id = hashlib.sha256(data.encode('utf-8')).hexdigest()
                object_img_hashs.append(img_id)
                db_insert(f"INSERT INTO images(id,data) VALUES ('{img_id}','{data}')")
            else:
                print("img exists")
                object_img_hashs.append(check_exists[0]["id"])
        total_images_set += object_img_hashs
        total_images_set = {
            "id_list": total_images_set
        }
        print(f"UPDATE buildings SET images = '{json.dumps(total_images_set)}' WHERE id = '{object_id}'")
        db_insert(f"UPDATE buildings SET images = '{json.dumps(total_images_set)}' WHERE id = '{object_id}'")
        return build_response({},{},200)
if __name__ == '__main__':
    app.run(host="192.168.1.64", port=5000)