import json


def isJson(string):
    if type(string) is not str and type(string) is not bytes and type(string) is not list:
        return False
    if type(string) is list:
        return True
    try:
        json.loads(string)
    except:
        return False
    return True