import hashlib

import requests
import base64
from io import BytesIO
from PIL import Image
import os
from db import db_select, db_insert
import time

def download_and_fill(url):
    r = requests.get(url)
    data = base64.b64encode(r.content).decode('utf-8')
    check_exists = db_select(f"SELECT * FROM images WHERE data = '{data}'")
    if len(check_exists) == 0:
        img_id = hashlib.sha256(data.encode('utf-8')).hexdigest()
        db_insert(f"INSERT INTO images(id,data) VALUES ('{img_id}','{data}')")
        return True
    else:
        return False


#r = requests.get("https://www.phcppros.com/ext/resources/2021/08/02/PE0821_very-tall-buildings.jpg?t=1628481696&width=1080")
f = open("test.jpg", "rb")
data = f.read()
f.close()
img = Image.open(BytesIO(data))
img = img.resize((600, 400))
img.show()