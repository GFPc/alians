import React from "react";

import "../styles.scss";

export default function SlideTitle({ title }) {
  return <div className="slide-title">{title}</div>;
}
